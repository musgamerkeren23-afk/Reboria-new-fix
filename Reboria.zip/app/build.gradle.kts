plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.h4ll0.reboria"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.h4ll0.reboria"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "0.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
