package com.h4ll0.reboria

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

// Dipakai buat semua halaman web di dalam app: game.html dan avatar.html
class GameActivity : Activity() {

    private lateinit var web: WebView
    private var gameId = "first"

    inner class Bridge {
        @JavascriptInterface
        fun token(): String =
            getSharedPreferences("reboria", MODE_PRIVATE).getString("token", "") ?: ""

        @JavascriptInterface
        fun username(): String =
            getSharedPreferences("reboria", MODE_PRIVATE).getString("username", "Tamu") ?: "Tamu"

        @JavascriptInterface
        fun api(): String = Api.BASE

        @JavascriptInterface
        fun gameId(): String = gameId

        @JavascriptInterface
        fun exit() {
            runOnUiThread { finish() }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val page = intent.getStringExtra("page") ?: "game.html"
        gameId = intent.getStringExtra("game_id") ?: "first"

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/$page")
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
