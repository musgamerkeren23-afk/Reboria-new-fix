package com.h4ll0.reboria

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("reboria", MODE_PRIVATE) }
    private val bg = Color.parseColor("#12121A")
    private val accent = Color.parseColor("#7C5CFF")
    private val danger = Color.parseColor("#FF6B6B")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (prefs.getString("token", null) != null) showHome() else showAuth()
    }

    // ---------- helper UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setBackgroundColor(bg)
        c.setPadding(dp(20), dp(40), dp(20), dp(20))
        return c
    }

    private fun label(text: String, size: Float, color: Int = Color.WHITE): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        return t
    }

    private fun input(hint: String, password: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.GRAY)
        e.inputType = if (password) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT
        }
        return e
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(accent)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun gap(h: Int = 12): Space {
        val s = Space(this)
        s.minimumHeight = dp(h)
        return s
    }

    // ---------- layar login / daftar ----------
    private fun showAuth() {
        val root = column()
        root.addView(label("REBORIA", 32f, accent))
        root.addView(label("Masuk atau daftar dulu", 14f, Color.LTGRAY))
        root.addView(gap(20))

        val user = input("Username")
        val pass = input("Password", true)
        val status = label("", 13f, danger)
        root.addView(user)
        root.addView(pass)
        root.addView(gap())

        fun submit(path: String) {
            val u = user.text.toString().trim()
            val p = pass.text.toString()
            status.text = "Menghubungi server..."
            Thread {
                val res = try {
                    Api.request("POST", path, JSONObject().put("username", u).put("password", p))
                } catch (e: Exception) {
                    JSONObject().put("error", "Gak bisa konek: ${e.message}")
                }
                runOnUiThread {
                    if (res.has("token")) {
                        prefs.edit()
                            .putString("token", res.getString("token"))
                            .putString("username", res.optString("username"))
                            .apply()
                        showHome()
                    } else {
                        status.text = res.optString("error", "Gagal")
                    }
                }
            }.start()
        }

        root.addView(button("MASUK") { submit("/login") })
        root.addView(gap(8))
        root.addView(button("DAFTAR") { submit("/register") })
        root.addView(gap())
        root.addView(status)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.addView(root)
        setContentView(scroll)
    }

    // ---------- layar utama: list game ----------
    private fun showHome() {
        val root = column()
        root.addView(label("Halo, ${prefs.getString("username", "")}", 20f))
        root.addView(gap(8))

        val status = label("Memuat game...", 13f, Color.LTGRAY)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL

        fun load() {
            status.text = "Memuat game..."
            Thread {
                val res = try {
                    Api.request("GET", "/games")
                } catch (e: Exception) {
                    JSONObject().put("error", "Gak bisa konek: ${e.message}")
                }
                runOnUiThread {
                    list.removeAllViews()
                    val arr = res.optJSONArray("games")
                    if (arr == null) {
                        status.text = res.optString("error", "Gagal memuat")
                    } else {
                        status.text = if (arr.length() == 0) "Belum ada game. Bikin yang pertama!" else ""
                        for (i in 0 until arr.length()) {
                            val g = arr.getJSONObject(i)
                            list.addView(label(g.getString("title"), 18f))
                            list.addView(
                                label(
                                    "oleh ${g.getString("owner")}  •  ${g.optString("description", "")}",
                                    13f,
                                    Color.LTGRAY
                                )
                            )
                            list.addView(gap(14))
                        }
                    }
                }
            }.start()
        }

        fun createGame() {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(20), dp(10), dp(20), 0)
            val title = EditText(this)
            title.hint = "Judul game"
            val desc = EditText(this)
            desc.hint = "Deskripsi"
            box.addView(title)
            box.addView(desc)

            AlertDialog.Builder(this)
                .setTitle("Bikin game")
                .setView(box)
                .setPositiveButton("Buat") { _, _ ->
                    val body = JSONObject()
                        .put("title", title.text.toString())
                        .put("description", desc.text.toString())
                    Thread {
                        val res = try {
                            Api.request("POST", "/games", body, prefs.getString("token", null))
                        } catch (e: Exception) {
                            JSONObject().put("error", "Gak bisa konek")
                        }
                        runOnUiThread {
                            if (res.has("error")) {
                                val msg = res.getString("error")
                                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                                if (msg == "Belum login") {
                                    prefs.edit().clear().apply()
                                    showAuth()
                                }
                            } else {
                                load()
                            }
                        }
                    }.start()
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        root.addView(button("BIKIN GAME") { createGame() })
        root.addView(gap(8))
        root.addView(button("REFRESH") { load() })
        root.addView(gap(8))
        root.addView(button("KELUAR") {
            prefs.edit().clear().apply()
            showAuth()
        })
        root.addView(gap())
        root.addView(status)
        root.addView(list)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.addView(root)
        setContentView(scroll)
        load()
    }
}
