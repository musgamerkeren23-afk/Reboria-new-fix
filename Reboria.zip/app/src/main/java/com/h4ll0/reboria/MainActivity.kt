package com.h4ll0.reboria

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView
import org.json.JSONObject

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("reboria", MODE_PRIVATE) }

    // Warna default: putih
    private val bg = Color.WHITE
    private val ink = Color.parseColor("#1B1B1F")
    private val sub = Color.parseColor("#6B6B76")
    private val accent = Color.parseColor("#7C5CFF")
    private val danger = Color.parseColor("#D93025")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (prefs.getString("token", null) != null) showHome() else showAuth()
    }

    // ---------- helper UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setBackgroundColor(bg)
        c.setPadding(dp(20), dp(40), dp(20), dp(20))
        return c
    }

    private fun label(text: String, size: Float, color: Int = ink): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        return t
    }

    private fun input(hint: String, password: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setTextColor(ink)
        e.setHintTextColor(Color.GRAY)
        e.inputType = if (password) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT
        }
        return e
    }

    private fun button(text: String, color: Int = accent, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(color)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun gap(h: Int = 12): Space {
        val s = Space(this)
        s.minimumHeight = dp(h)
        return s
    }

    private fun open(page: String, gameId: String) {
        val i = Intent(this, GameActivity::class.java)
        i.putExtra("page", page)
        i.putExtra("game_id", gameId)
        startActivity(i)
    }

    // ---------- layar login / daftar ----------
    private fun showAuth() {
        val root = column()
        root.addView(label("REBORIA", 32f, accent))
        root.addView(label("Masuk atau daftar dulu", 14f, sub))
        root.addView(gap(20))

        val user = input("Username")
        val pass = input("Password", true)
        val status = label("", 13f, danger)
        root.addView(user)
        root.addView(pass)
        root.addView(gap())

        fun submit(path: String) {
            val u = user.text.toString().trim()
            val p = pass.text.toString()
            status.text = "Menghubungi server..."
            Thread {
                val res = try {
                    Api.request("POST", path, JSONObject().put("username", u).put("password", p))
                } catch (e: Exception) {
                    JSONObject().put("error", "Gak bisa konek: ${e.message}")
                }
                runOnUiThread {
                    if (res.has("token")) {
                        prefs.edit()
                            .putString("token", res.getString("token"))
                            .putString("username", res.optString("username"))
                            .apply()
                        showHome()
                    } else {
                        status.text = res.optString("error", "Gagal")
                    }
                }
            }.start()
        }

        root.addView(button("MASUK") { submit("/login") })
        root.addView(gap(8))
        root.addView(button("DAFTAR") { submit("/register") })
        root.addView(gap())
        root.addView(status)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.addView(root)
        setContentView(scroll)
    }

    // ---------- layar utama ----------
    private fun showHome() {
        val root = column()
        root.addView(label("Halo, ${prefs.getString("username", "")}", 20f))
        root.addView(gap(14))

        root.addView(button("▶  First Game!") { open("game.html", "first") })
        root.addView(gap(8))
        root.addView(button("👤  Avatar & Shop") { open("avatar.html", "first") })
        root.addView(gap(8))
        root.addView(button("🔨  Bikin Game") { open("game.html", "new") })
        root.addView(gap(20))
        root.addView(label("Game komunitas (tap buat main)", 16f, sub))
        root.addView(gap(8))

        val status = label("Memuat game...", 13f, sub)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL

        fun load() {
            status.text = "Memuat game..."
            Thread {
                val res = try {
                    Api.request("GET", "/games")
                } catch (e: Exception) {
                    JSONObject().put("error", "Gak bisa konek: ${e.message}")
                }
                runOnUiThread {
                    list.removeAllViews()
                    val arr = res.optJSONArray("games")
                    if (arr == null) {
                        status.text = res.optString("error", "Gagal memuat")
                    } else {
                        status.text = if (arr.length() == 0) "Belum ada game. Bikin yang pertama!" else ""
                        for (i in 0 until arr.length()) {
                            val g = arr.getJSONObject(i)
                            val card = LinearLayout(this)
                            card.orientation = LinearLayout.VERTICAL
                            card.setPadding(0, dp(8), 0, dp(8))
                            card.addView(label(g.getString("title"), 18f))
                            card.addView(label("oleh ${g.getString("owner")}", 13f, sub))
                            val id = g.getInt("id").toString()
                            card.setOnClickListener { open("game.html", id) }
                            list.addView(card)
                        }
                    }
                }
            }.start()
        }

        root.addView(status)
        root.addView(list)
        root.addView(gap())
        root.addView(button("REFRESH") { load() })
        root.addView(gap(8))
        root.addView(button("KELUAR", sub) {
            prefs.edit().clear().apply()
            showAuth()
        })

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.addView(root)
        setContentView(scroll)
        load()
    }

    override fun onResume() {
        super.onResume()
    }
}
