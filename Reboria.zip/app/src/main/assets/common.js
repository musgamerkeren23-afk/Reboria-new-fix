var PALETTE = ["#ffffff","#e0e0e0","#9aa0a6","#2b2b2b","#e53935","#fb8c00","#fdd835","#43a047",
               "#1e88e5","#8e24aa","#ec407a","#8d6e63","#00acc1","#7cb342","#ffd54f","#90caf9"];
var DEFAULT_AVATAR = { head: "#ffffff", torso: "#ffffff", arms: "#ffffff", legs: "#ffffff", hat: "none" };

function fixAvatar(a) {
  var o = {};
  for (var k in DEFAULT_AVATAR) o[k] = (a && a[k]) || DEFAULT_AVATAR[k];
  return o;
}

function hm(c) { return new THREE.MeshLambertMaterial({ color: c }); }

function buildHat(group, id) {
  while (group.children.length) group.remove(group.children[0]);
  var m;
  if (id === "hat_cap") {
    m = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.3, 1.1), hm(0xe53935)); m.position.set(0, 5.1, 0);
    var v = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.1, 0.55), hm(0xb71c1c)); v.position.set(0, 5.0, 0.8);
    group.add(m); group.add(v);
  } else if (id === "hat_tophat") {
    m = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.1, 16), hm(0x222222)); m.position.set(0, 5.05, 0);
    var t = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 1.1, 16), hm(0x222222)); t.position.set(0, 5.6, 0);
    group.add(m); group.add(t);
  } else if (id === "hat_crown") {
    m = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.4, 12), hm(0xffc107)); m.position.set(0, 5.2, 0);
    group.add(m);
    [[-0.4, -0.4], [0.4, -0.4], [-0.4, 0.4], [0.4, 0.4]].forEach(function (p) {
      var s = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.4, 6), hm(0xffc107));
      s.position.set(p[0], 5.6, p[1]); group.add(s);
    });
  } else if (id === "hat_horns") {
    [-1, 1].forEach(function (sx) {
      var h = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.8, 8), hm(0xd32f2f));
      h.position.set(0.4 * sx, 5.4, 0); h.rotation.z = -0.35 * sx; group.add(h);
    });
  } else if (id === "hat_halo") {
    m = new THREE.Mesh(new THREE.TorusGeometry(0.65, 0.07, 8, 20), new THREE.MeshBasicMaterial({ color: 0xffeb3b }));
    m.position.set(0, 6.0, 0); m.rotation.x = Math.PI / 2; group.add(m);
  }
}

function makeAvatar(scene, avatar, name) {
  var lineMat = new THREE.LineBasicMaterial({ color: 0x555555 });
  var mats = {};
  ["head", "torso", "arms", "legs"].forEach(function (k) { mats[k] = hm(0xffffff); });
  var root = new THREE.Group();

  function part(mat, w, h, d, x, y, z) {
    var m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    m.add(new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry), lineMat));
    return m;
  }
  root.add(part(mats.torso, 2, 2, 1, 0, 3, 0));
  root.add(part(mats.head, 1, 1, 1, 0, 4.5, 0));

  var black = new THREE.MeshBasicMaterial({ color: 0x111111 });
  function dot(w, h, x, y) {
    var m = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.05), black);
    m.position.set(x, y, 0.52); return m;
  }
  root.add(dot(0.14, 0.14, -0.22, 4.6));
  root.add(dot(0.14, 0.14, 0.22, 4.6));
  root.add(dot(0.44, 0.08, 0, 4.3));

  function limb(mat, x, y) {
    var pivot = new THREE.Group();
    pivot.position.set(x, y, 0);
    pivot.add(part(mat, 1, 2, 1, 0, -1, 0));
    root.add(pivot);
    return pivot;
  }
  var armL = limb(mats.arms, -1.5, 4), armR = limb(mats.arms, 1.5, 4);
  var legL = limb(mats.legs, -0.5, 2), legR = limb(mats.legs, 0.5, 2);

  var hatGroup = new THREE.Group();
  root.add(hatGroup);

  var c = document.createElement("canvas");
  c.width = 256; c.height = 64;
  var x = c.getContext("2d");
  x.font = "bold 32px sans-serif"; x.textAlign = "center"; x.textBaseline = "middle";
  x.lineWidth = 6; x.strokeStyle = "rgba(0,0,0,.7)"; x.strokeText(name, 128, 32);
  x.fillStyle = "#fff"; x.fillText(name, 128, 32);
  var sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthTest: false }));
  sp.position.set(0, 7.3, 0); sp.scale.set(6, 1.5, 1);
  root.add(sp);

  scene.add(root);
  var api = {
    root: root, armL: armL, armR: armR, legL: legL, legR: legR,
    setAvatar: function (a) {
      a = fixAvatar(a);
      mats.head.color.set(a.head); mats.torso.color.set(a.torso);
      mats.arms.color.set(a.arms); mats.legs.color.set(a.legs);
      buildHat(hatGroup, a.hat);
    }
  };
  api.setAvatar(avatar);
  return api;
}
